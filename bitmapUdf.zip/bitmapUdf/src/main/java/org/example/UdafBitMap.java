package org.example;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.expressions.MutableAggregationBuffer;
import org.apache.spark.sql.expressions.UserDefinedAggregateFunction;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.roaringbitmap.RoaringBitmap;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * 实现自定义聚合函数Bitmap
 */
public class UdafBitMap extends UserDefinedAggregateFunction {

    //聚合函数的输入数据结构
    @Override
    public StructType inputSchema() {
        List<StructField> structFields = new ArrayList<>();
        structFields.add(DataTypes.createStructField("field", DataTypes.BinaryType, true));
        return DataTypes.createStructType(structFields);
    }

    //缓存数据的数据结构
    @Override
    public StructType bufferSchema() {
        List<StructField> structFields = new ArrayList<>();
        structFields.add(DataTypes.createStructField("field", DataTypes.BinaryType, true));
        return DataTypes.createStructType(structFields);
    }

    //返回数据类型的数据结构
    @Override
    public DataType dataType() {
        return DataTypes.LongType;
    }

    //是否强制执行每次相同的结果
    @Override
    public boolean deterministic() {
        return false;
    }

    @Override
    public void initialize(MutableAggregationBuffer buffer) {
        //初始化
        buffer.update(0, null);
    }

    //给聚合函数传入一条数据时候的处理逻辑
    @Override
    public void update(MutableAggregationBuffer buffer, Row input) {
        //相同executor间的数据合并
        //1、输入为空直接返回不更新
        Object in = input.get(0);
        if (in == null) {
            return;
        }
        //2、源为空则直接更新为输入
        byte[] inBytes = (byte[]) in;
        Object out = buffer.get(0);
        if(out == null){
            buffer.update(0,inBytes);
            return;
        }
        // 3. 源和输入都不为空使用bitmap去重合并
        byte[] outBytes = (byte[]) out;
        byte[] result = outBytes;
        RoaringBitmap outRR = new RoaringBitmap();
        RoaringBitmap inRR = new RoaringBitmap();
        try {
            outRR.deserialize(ByteBuffer.wrap(outBytes));
            inRR.deserialize(ByteBuffer.wrap(inBytes));
            outRR.or(inRR);
            byte[] results = new byte[outRR.serializedSizeInBytes()];
            outRR.serialize(ByteBuffer.wrap(results));
        } catch (IOException e) {
            e.printStackTrace();
        }
        buffer.update(0, result);
    }

    @Override
    public void merge(MutableAggregationBuffer buffer1, Row buffer2) {
        //不同excutor间的数据合并
        update(buffer1, buffer2);
    }

    @Override
    public Object evaluate(Row buffer) {
        //根据Buffer计算结果
        long r = 0L;
        Object val = buffer.get(0);
        if (val != null) {
            RoaringBitmap rr = new RoaringBitmap();
            try {
                rr.deserialize(ByteBuffer.wrap((byte[]) val));
        //返回具体bitmap的长度
                r = rr.getLongCardinality();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return r;
    }


}
