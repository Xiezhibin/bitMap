package org.example;

import java.util.*;

public class test {

    Deque<String> s = new LinkedList<>();
    List<String> ss = new ArrayList<>();
    Deque<String> sss = new LinkedList<>();
    HashMap<Integer,String> a = new HashMap<>();
    Queue<Integer> queue = new PriorityQueue<>((a, b) -> a - b);

    public static void main(String[] args) {
        List<String> ss = new ArrayList<>();
        Object[] objects = Arrays.copyOf(ss.toArray(), 100, Object[].class);
        Collections.sort(ss, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return 0;
            }
        });
        Collections.sort(ss, (o1, o2) -> {
            return o2.charAt(0) - o1.charAt(0);
        });
        Arrays.sort(ss.toArray(new String[0]),(o1, o2) -> o2.length() - o1.length());
        System.out.println(Object[].class);
    }

}
