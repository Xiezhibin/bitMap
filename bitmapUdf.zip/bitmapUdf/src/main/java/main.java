import org.roaringbitmap.RoaringBitmap;


import java.io.*;
import java.nio.ByteBuffer;
import java.util.Arrays;


public class main {
    public static void main(String[] args) throws IOException {
        RoaringBitmap mrb = RoaringBitmap.bitmapOf(1, 2, 3, 4);
        System.out.println("starting with  bitmap " + mrb);
        mrb.runOptimize();
        byte[] array = new byte[mrb.serializedSizeInBytes()];
        System.out.println(mrb.serializedSizeInBytes());
        mrb.serialize(ByteBuffer.wrap(array));
        RoaringBitmap ret = new RoaringBitmap();
        ret.deserialize(ByteBuffer.wrap(array));
        System.out.println("ret1:" + ret);
        RoaringBitmap ret2 = new RoaringBitmap();
        ret2.deserialize(new DataInputStream(new ByteArrayInputStream(array)));
        System.out.println(ret2);

        //
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ret.serialize(new DataOutputStream(bos));
        byte[] result = bos.toByteArray();
        System.out.println("result:" + Arrays.toString(result));

        byte[] array1 = new byte[ret.serializedSizeInBytes()];
        ret.serialize(ByteBuffer.wrap(array1));
        System.out.println("array1:" + Arrays.toString(array1));


        System.out.println(ret);



        try {
            ret.deserialize(ByteBuffer.wrap(array));
        } catch(IOException ioe) {
            ioe.printStackTrace(); // should not happen
        }
        if (!ret.equals(mrb)) {
            throw new RuntimeException("bug");
        }
        System.out.println("decoded from byte array : " + ret);

    }
}
